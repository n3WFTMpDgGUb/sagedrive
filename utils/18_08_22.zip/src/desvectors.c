#include <assert.h>
#include "machine.h"
#include "mjskarn.h"
#include <stdio.h>

enum {
	ENCRYPT = 0,
	DECRYPT = 1
};

static void show(char *str, U8 *x, int n) {
	int i,j;
	enum {N_PER_LINE = 16};
	printf("%s:\n", str);

	if (n >= 0) {
		for (i=0; i<n; i++) {
			printf("%02x ", x[i]);
			j = i+1;
			if (((j%N_PER_LINE) == 0) || (j == n)) printf("\n");
		}
	}
	else {
		n = -n;
		for (i=n-1; i>=0; i--) {
			printf("%02x ", x[i]);
			j = n-i;
			if (((j%N_PER_LINE) == 0) || (j == n)) printf("\n");
		}
	}
}

void des3ecb(U8 *key, U8 *src, U8 *dest, int decryptFlag) {

	Des3ctx ctx;

	des3ecb_init(&ctx, key, decryptFlag);
	des3ecb_crunch(&ctx, src, dest);
}

typedef struct {
	U8 key[24];
	U8 plain[8];
	U8 cipher[8];
} Vector;

Vector vectors[] = {
	{
		// From NIST 800-67, revised January 2012, Appendix B.1 and B.2.

		//key
		{
		0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF, 0x23,
		0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF, 0x01, 0x45, 0x67,
		0x89, 0xAB, 0xCD, 0xEF, 0x01, 0x23
		},

		// plain
		{
		0x54, 0x68, 0x65, 0x20, 0x71, 0x75, 0x66, 0x63
		},

		// cipher
		{
		0xA8, 0x26, 0xFD, 0x8C, 0xE5, 0x3B, 0x85, 0x5F
		}
	}
};

enum {
	N_VECTORS = sizeof(vectors) / sizeof(Vector)
};

int main(void) {

	U8 key[24], plain[8], cipher[8], clear[8];
	int nvec;
	Vector *vector;

	for (nvec = 0; nvec < N_VECTORS; nvec++) {

		vector = &vectors[nvec];
		memcpy(key, vector->key, sizeof(key));
		memcpy(plain, vector->plain, sizeof(plain));

		des3ecb(key, plain, cipher, ENCRYPT);
		des3ecb(key, cipher, clear, DECRYPT);

		show("key", key, sizeof(key));
		show("plain", plain, sizeof(plain));
		show("cipher", cipher, sizeof(cipher));
		show("clear", clear, sizeof(clear));

		assert(memcmp(cipher, vector->cipher, sizeof(cipher)) == 0);
		assert(memcmp(clear, vector->plain, sizeof(clear)) == 0);

	}
}
