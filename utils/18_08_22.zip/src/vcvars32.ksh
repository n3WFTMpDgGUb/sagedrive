# At ksh prompt, execute this file (type "vcvars32").
# At cmd prompt, type "sh".
#     Compile, link, etc.
# When done, "exit" to get to cmd prmomp, "exit" to get to ksh prompt.
#
cmd /k c:/program\ files\ \(x86\)/Microsoft\ Visual\ Studio\ 10.0/VC//vcvarsall.bat x86
