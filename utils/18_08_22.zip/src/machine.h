#ifndef MACHINE_H
#define MACHINE_H

typedef unsigned char U8;
typedef unsigned long U32;

#endif
