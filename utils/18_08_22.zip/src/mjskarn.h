#ifndef _MJSKARN_DOT_H
#define _MJSKARN_DOT_H

typedef struct {
	unsigned long keySked[48][2];	
	int decryptFlag;
} Des3ctx;

void des3ecb_init(
	Des3ctx *ctx, unsigned char key[24], int decryptFlag
);

void des3ecb_crunch(
	Des3ctx *ctx, unsigned char src[8], unsigned char dest[8]
);

#endif
