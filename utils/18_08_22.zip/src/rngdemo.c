#include <assert.h>
#include <stdio.h>
#include <windows.h>

typedef unsigned char U8;

static void show(char *str, U8 *x, int n) {
	int i,j;
	enum {N_PER_LINE = 16};
	printf("%s:\n", str);

	if (n >= 0) {
		for (i=0; i<n; i++) {
			printf("%02x ", x[i]);
			j = i+1;
			if (((j%N_PER_LINE) == 0) || (j == n)) printf("\n");
		}
	}
	else {
		n = -n;
		for (i=n-1; i>=0; i--) {
			printf("%02x ", x[i]);
			j = n-i;
			if (((j%N_PER_LINE) == 0) || (j == n)) printf("\n");
		}
	}
}

void main() {

	HCRYPTPROV   hCryptProv;
	U8 buf[32];
	int status;
	enum {NBYTES = sizeof(buf)};

	// Acquire a cryptographic provider context handle.
	// The provider type (RSA_FULL) is a dummy value for purposes here.
	status = CryptAcquireContext(&hCryptProv, NULL, NULL, PROV_RSA_FULL, 0) ;
	assert(status);


	// Generate random bytes
	status = CryptGenRandom(hCryptProv, NBYTES, buf);
	assert(status);
	show("random bytes", buf, NBYTES);


	// Release context
	status = CryptReleaseContext(hCryptProv, 0);
	assert(status);

}
