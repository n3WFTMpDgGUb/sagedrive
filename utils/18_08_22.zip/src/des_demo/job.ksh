set -x

# Hint:  Use od utility to view the data files.

# Example #1. From
# 
# 	https://csrc.nist.gov/CSRC/media/Projects/
# 	Cryptographic-Standards-and-Guidelines/documents/examples/tdes_cbc.pdf
# 
# accessed 3 Aug 2018.  Copy included here.
# In order to match a known cipher output, need to specify the iv_nonce,
# as otherwise it is randomly generated.
#
../descrypt e plain1.dat junk1 $(cat key.txt) $(cat iv_nonce.txt)
cmp junk1 cipher1.dat

# A general example.  Input is not a multiple of blocksize (8 bytes).
# First specify iv_nonce so that cipher matches.
#
../descrypt e plain2.dat junk2 $(cat key.txt) $(cat iv_nonce.txt)
cmp junk2 cipher2.dat

# Same example, but without specifying iv_nonce, as is the usual case.
# Now cipher doesn't match but decrypts correctly.
../descrypt e plain2.dat junk2 $(cat key.txt) 
cmp junk2 cipher2.dat
../descrypt d junk2 junk3 $(cat key.txt) 
cmp junk3 plain2.dat

# Same example, using pipe.
../descrypt e plain2.dat - $(cat key.txt) | ../descrypt d - junk2 $(cat key.txt)
cmp junk2 plain2.dat
