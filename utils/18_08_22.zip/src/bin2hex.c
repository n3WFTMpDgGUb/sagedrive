#include <stdio.h>

int main(int nargs, char *arg[]) {

	enum {N_PER_LINE = 16};

	FILE *fin;
	int j, x;

	if (nargs != 2) {
		fprintf(stderr, "Usage: %s infile\n", arg[0]);
		return 1;
	}

	fin = fopen(arg[1], "rb");
	if (!fin) {
		fprintf(stderr, "%s: cannot open %s\n", arg[0], arg[1]);
		return 1;
	}

	j = 0;
	for(;;) {
		x = fgetc(fin);
		if (x == EOF) break;

		printf("%02x ", x);
		if (++j == N_PER_LINE) {
			printf("\n");
			j = 0;
		}
	}
	if (j > 0) printf("\n");

	fclose(fin);


	return 0;
}
