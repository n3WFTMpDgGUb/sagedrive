#include <stdio.h>
int main(int nargs, char *arg[]) {

	FILE *fin, *fout;
	int n, x;

	if (nargs != 3) {
		fprintf(stderr, "Usage: %s infile outfile\n", arg[0]);
		return 1;
	}

	fin = fopen(arg[1], "r");
	if (!fin) {
		fprintf(stderr, "%s: cannot open %s\n", arg[0], arg[1]);
		return 1;
	}

	fout = fopen(arg[2], "wb");
	if (!fout) {
		fprintf(stderr, "%s: cannot open %s\n", arg[0], arg[2]);
		return 1;
	}

	for(;;) {
		n = fscanf(fin, "%02x", &x);
		if (n != 1) break;
		fputc(x, fout);
	}

	return 0;
}
