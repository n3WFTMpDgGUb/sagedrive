#ifndef _DES3_CBC_H
#define _DES3_CBC_H

#include "machine.h"
#include <stdio.h>

enum {BLOCKSIZE = 8, KEYSIZE = 24};  // bytes

void des3_cbc_encrypt(U8 *key, U8 *iv_nonce, FILE *fin, FILE *fout);
void des3_cbc_decrypt(U8 *key, FILE *fin, FILE *fout);

#endif

