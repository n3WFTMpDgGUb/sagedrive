#include <assert.h>
#include <ctype.h>
#include "des3_cbc.h"
#include <fcntl.h>
#include <io.h>
#include "machine.h"
#include <stdio.h>
#include <windows.h>

enum {KEYBITS = KEYSIZE*8, KEYCHARS = KEYSIZE*2};
enum {BLOCKBITS = BLOCKSIZE*8, BLOCKCHARS = BLOCKSIZE*2};

#if 0
static void show(char *str, U8 *x, int n) {
	int i,j;
	enum {N_PER_LINE = 16};
	printf("%s:\n", str);

	if (n >= 0) {
		for (i=0; i<n; i++) {
			printf("%02x ", x[i]);
			j = i+1;
			if (((j%N_PER_LINE) == 0) || (j == n)) printf("\n");
		}
	}
	else {
		n = -n;
		for (i=n-1; i>=0; i--) {
			printf("%02x ", x[i]);
			j = n-i;
			if (((j%N_PER_LINE) == 0) || (j == n)) printf("\n");
		}
	}
}
#endif

static int getHexVal(char *str, U8 *dest, int nbytes) {

	int i, x;
	int nchars = 2 * nbytes;

	// Error if str is the wrong length
	if (strlen(str) != nchars) return 1;

	// Error if str is not a hex string
	for (i=0; i<nchars; i++) {
		if (!isxdigit(str[i])) return 2;
	}

	// All good.  Convert str.
	for (i=0; i<nbytes; i++) {
		sscanf(str + 2*i, "%2x", &x);
		dest[i] = (U8)x;
	}

	return 0;
}

static void genRandom(U8 *dest, int nbytes) {

	HCRYPTPROV   hCryptProv;
	int status;

	// Acquire a cryptographic provider context handle.
	// The provider type (RSA_FULL) is a dummy value for purposes here.
	status = CryptAcquireContext(&hCryptProv, NULL, NULL, PROV_RSA_FULL, 0) ;
	assert(status);


	// Generate random bytes
	status = CryptGenRandom(hCryptProv, nbytes, dest);
	assert(status);


	// Release context
	status = CryptReleaseContext(hCryptProv, 0);
	assert(status);

}

int main(int nargs, char *arg[]) {

	int decryptFlag;
	U8 key[KEYSIZE], iv_nonce[BLOCKSIZE];
	FILE *fin, *fout;

	int status = 0;

	if ((nargs != 5) && (nargs != 6)) {
		fprintf(stderr, "Usage: %s e|d file_in file_out key [iv_nonce]\n", arg[0]);
		fprintf(stderr, "Key is hex string of length %d bits (%d hex digits).\n", 
			KEYBITS, KEYCHARS);
		fprintf(stderr, "Optional iv_nonce is hex string of length %d bits (%d hex digits),\n", 
			BLOCKBITS, BLOCKCHARS);
		fprintf(stderr, "  ignored if operation is decrypt.\n");
		fprintf(stderr, "File_in or file_out may be \"-\" for stdin or stdout.\n");
		status = 1;
		goto oops;
	}

	if (!strcmp(arg[1], "e")) decryptFlag = 0;
	else if (!strcmp(arg[1], "d")) decryptFlag = 1;
	else {
		fprintf(stderr, "%s: Unrecognized option %s\n", arg[0], arg[1]);
		status = 1;
		goto oops;
	}

	if (!strcmp(arg[2], "-")) {
		fin = stdin;
		status = _setmode(_fileno(stdin), _O_BINARY);
		assert(status != -1);
		status = 0;
	}
	else {
		fin = fopen(arg[2], "rb");
		if (!fin) {
			fprintf(stderr, "%s:  Cannot open %s\n", arg[0], arg[2]);
			status = 1;
			goto oops;
		}
	}

	if (!strcmp(arg[3], "-")) {
		fout = stdout;
		status = _setmode(_fileno(stdout), _O_BINARY);
		assert(status != -1);
		status = 0;
	}
	else {
		fout = fopen(arg[3], "wb");
		if (!fout) {
			fprintf(stderr, "%s:  Cannot open %s\n", arg[0], arg[3]);
			status = 1;
			goto oops;
		}
	}

	// Get key from string argument
	status = getHexVal(arg[4], key, KEYSIZE);
	if (status) {
		fprintf(stderr, "%s:  Invalid key format\n", arg[0]);
		fprintf(stderr, "Key is hex string of length %d bits (%d hex digits)\n", KEYBITS, KEYCHARS);
		goto oops;
	}

	// If encrypting, get IV nonce
	if (!decryptFlag) {

		if (nargs == 6) {
			// Get IV nonce from string argument
			status = getHexVal(arg[5], iv_nonce, BLOCKSIZE);
			if (status) {
				fprintf(stderr, "%s:  Invalid iv_nonce format\n", arg[0]);
				fprintf(stderr, "Iv_nonce is hex string of length %d bits (%d hex digits)\n", 
					BLOCKBITS, BLOCKCHARS);
				goto oops;
			}
		}

		else {
			// Generate random IV nonce.
			genRandom(iv_nonce, sizeof(iv_nonce));
		}
	}


	//show("key", key, sizeof(key));
	//show("iv_nonce", iv_nonce, sizeof(key));

	if (!decryptFlag) {
		des3_cbc_encrypt(key, iv_nonce, fin, fout);
	}
	else {
		des3_cbc_decrypt(key, fin, fout);
	}

oops:
	return status;
}
