set -x

# Hint:  Use od utility to view the data files.

# Example #1

# NIST 800-38A example F.2.5 CBC-AES256.Encrypt
# In order to match a known cipher output, need to specify the iv_nonce,
# as otherwise it is randomly generated.
#
../aescrypt e plain1.dat junk1 $(cat key.txt) $(cat iv_nonce.txt)
cmp junk1 cipher1.dat

# Example #2

# A general example.  Input is not a multiple of blocksize (16 bytes).
# First specify iv_nonce so that cipher matches.
#
../aescrypt e plain2.dat junk2 $(cat key.txt) $(cat iv_nonce.txt)
cmp junk2 cipher2.dat

# Same example, but without specifying iv_nonce, as is the usual case.
# Now cipher doesn't match but decrypts correctly.
../aescrypt e plain2.dat junk2 $(cat key.txt) 
cmp junk2 cipher2.dat
../aescrypt d junk2 poo2 $(cat key.txt) 
cmp poo2 plain2.dat

# Same example, using pipe.
../aescrypt e plain2.dat - $(cat key.txt) | ../aescrypt d - junk2 $(cat key.txt)
cmp junk2 plain2.dat
