#include <assert.h>
#include "des3_cbc.h"
#include "mjskarn.h"
#include <stdio.h>
#include <string.h>

static void show(char *str, U8 *x, int n) {
	int i,j;
	enum {N_PER_LINE = 16};
	printf("%s:\n", str);

	if (n >= 0) {
		for (i=0; i<n; i++) {
			printf("%02x ", x[i]);
			j = i+1;
			if (((j%N_PER_LINE) == 0) || (j == n)) printf("\n");
		}
	}
	else {
		n = -n;
		for (i=n-1; i>=0; i--) {
			printf("%02x ", x[i]);
			j = n-i;
			if (((j%N_PER_LINE) == 0) || (j == n)) printf("\n");
		}
	}
}

static void xorArray(U8 *src1, U8 *src2, U8 *dest, int nbytes) {
	int i;
	for (i=0; i<nbytes; i++) {
		dest[i] = src1[i] ^ src2[i];
	}
}

void des3_cbc_encrypt(U8 *key, U8 *iv_nonce, FILE *fin, FILE *fout) {

	Des3ctx ctx;
	U8 inbuf[BLOCKSIZE], cbuf[BLOCKSIZE];
	int firstFlag, doneFlag, count, n, decryptFlag;


	/*
	CBC-CS1 as defined in NIST 800-38A addendum.

	Uses cipher stealing to handle case where input is not an
	integral number of blocks.

	Input stream must be at least BLOCKSIZE long.
	*/

	// Initialize DES ECB.
	decryptFlag = 0;
	des3ecb_init(&ctx, key, decryptFlag);

	// Generate IV by encrypting iv_nonce.
	// Per NIST 800-38A, Appendix C.
	// IV will be output later, as first cipher block.
	des3ecb_crunch(&ctx, iv_nonce, cbuf);

	firstFlag = 1;
	for (doneFlag=0; !doneFlag; ){

		// Read next input block
		count = fread(inbuf, sizeof(U8), BLOCKSIZE, fin);
		assert(!ferror(fin));

		if (count == BLOCKSIZE) {

			// Write previous cipher block
			fwrite(cbuf, sizeof(U8), BLOCKSIZE, fout);
			assert(!ferror(fout));

			// Exclusive-or input block with previous cipher block,
			// then encrypt.
			xorArray(inbuf, cbuf, inbuf, BLOCKSIZE);
			des3ecb_crunch(&ctx, inbuf, cbuf);

			firstFlag = 0;
		}

		else if (count == 0) {

			assert(!firstFlag);

			// Final input block was full size, so previous
			// cipher block is the last one.  Send it out, then
			// done.
			//
			fwrite(cbuf, sizeof(U8), BLOCKSIZE, fout);
			assert(!ferror(fout));

			doneFlag = 1;
		}

		else {

			/*
			Final input block is less than full size.
			Implement cipher stealing.

			Comments follow the notation of NIST 800-38A CBC-CS1.
			*/

			assert(!firstFlag);

			// Write C_{n-1}*,  the partial next-to-last cipher block
			fwrite(cbuf, sizeof(U8), count, fout);
			assert(!ferror(fout));
			//
			//show("C_{n-1}", cbuf, BLOCKSIZE);
			//show("C_{n-1}*", cbuf, count);

			// Form P_n, the partial last input block padded to full size.
			n = BLOCKSIZE - count;
			memset(inbuf + count, 0, n);
			//
			//show("P_n*", inbuf, count);
			//show("P_n", inbuf, BLOCKSIZE);

			// Form Z = C_{n-1} XOR P_n .
			xorArray(inbuf, cbuf, inbuf, BLOCKSIZE);
			//
			//show("Z = C_{n-1} XOR P_n", inbuf, BLOCKSIZE);

			// Encrypt Z to get C_n
			des3ecb_crunch(&ctx, inbuf, cbuf);
			//
			//show("C_n", cbuf, BLOCKSIZE);

			// Write C_n, the last cipher block (full size)
			fwrite(cbuf, sizeof(U8), BLOCKSIZE, fout);
			assert(!ferror(fout));

			doneFlag = 1;

		}
	}
}

void des3_cbc_decrypt(U8 *key, FILE *fin, FILE *fout) {

	Des3ctx ctx;
	U8 iv[BLOCKSIZE], cbuf[BLOCKSIZE], next_cbuf[BLOCKSIZE], outbuf[BLOCKSIZE];
	int count, doneFlag, firstFlag, n, decryptFlag;

	// Read IV and first cipher block
	count = fread(iv, sizeof(U8), BLOCKSIZE, fin);
	assert(!ferror(fin));
	assert (count == BLOCKSIZE);
	//
	count = fread(cbuf, sizeof(U8), BLOCKSIZE, fin);
	assert(!ferror(fin));
	assert (count == BLOCKSIZE);

	// Initialize DES ECB.
	decryptFlag = 1;
	des3ecb_init(&ctx, key, decryptFlag);

	firstFlag = 1;
	for (doneFlag=0; !doneFlag; ){

		// Read next cipher block
		count = fread(next_cbuf, sizeof(U8), BLOCKSIZE, fin);
		assert(!ferror(fin));

		if (count == BLOCKSIZE) {

			// Decrypt previous cipher block, then exclusive-or in the iv
			des3ecb_crunch(&ctx, cbuf, outbuf);
			xorArray(iv, outbuf, outbuf, BLOCKSIZE);

			// Write the output block
			fwrite(outbuf, sizeof(U8), BLOCKSIZE, fout);
			assert(!ferror(fout));

			// Copy cbuf to iv, next_cbuf to cbuf
			memcpy(iv, cbuf, BLOCKSIZE);
			memcpy(cbuf, next_cbuf, BLOCKSIZE);

			firstFlag = 0;
		}

		else if (count == 0) {

			assert(!firstFlag);

			// Final cipher block was full size, so finish up
			// the CBC process, then done.
			//

			// Decrypt final cipher block, then exclusive-or in the iv
			des3ecb_crunch(&ctx, cbuf, outbuf);
			xorArray(iv, outbuf, outbuf, BLOCKSIZE);

			// Write the output block
			fwrite(outbuf, sizeof(U8), BLOCKSIZE, fout);
			assert(!ferror(fout));

			doneFlag = 1;
		}

		else {

			// Partial final block.  Implement cipher stealing.
			// Follow notation of NIST 800-38A CBC-CS1
			//
			U8 cbuf_n[BLOCKSIZE];  // C_n
			U8 cbuf_n1[BLOCKSIZE]; // C_{n-1}
			U8 pbuf_n[BLOCKSIZE];  // P_n
			U8 pbuf_n1[BLOCKSIZE]; // P_{n-1}
			U8 zbuf[BLOCKSIZE];    // Z

			assert(!firstFlag);

			n = BLOCKSIZE - count;

			// Assemble C_n  from tail of cbuf and head of next_cbuf
			memcpy(cbuf_n, cbuf + count, n);
			memcpy(cbuf_n + n, next_cbuf, count); 
			//
			//show("C_n", cbuf_n, BLOCKSIZE);

			// Decrypt to get Z (= C_{n-1} XOR P_n)
			des3ecb_crunch(&ctx, cbuf_n, zbuf);
			//
			//show("Z", zbuf, BLOCKSIZE);

			// Assemble C_{n-1} from head of cbuf and tail of zbuf
			memcpy(cbuf_n1, cbuf, count);
			memcpy(cbuf_n1 + count, zbuf + count, n);
			//
			//show("C_{n-1}", cbuf_n1, BLOCKSIZE);

			// Exclusive-or to get P_n
			xorArray(zbuf, cbuf_n1, pbuf_n, BLOCKSIZE);
			//
			//show("P_n", pbuf_n, BLOCKSIZE);

			// Decrypt and exclusive-or to get P_{n-1}
			des3ecb_crunch(&ctx, cbuf_n1, pbuf_n1);
			xorArray(iv, pbuf_n1, pbuf_n1, BLOCKSIZE);
			//
			//show("P_{n-1}", pbuf_n1, BLOCKSIZE);

			// Write the next-to-last block, P_{n-1}
			fwrite(pbuf_n1, sizeof(U8), BLOCKSIZE, fout);
			assert(!ferror(fout));

			// Write the last partial block, P_n* (from head of P_n)
			fwrite(pbuf_n, sizeof(U8), count, fout);
			assert(!ferror(fout));

			doneFlag = 1;
		}
	}
}
