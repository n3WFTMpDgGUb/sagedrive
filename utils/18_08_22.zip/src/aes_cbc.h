#ifndef _AES_CBC_H
#define _AES_CBC_H

#include "machine.h"
#include <stdio.h>

enum {BLOCKSIZE = 128/8, KEYSIZE = 256/8};

void aes_cbc_encrypt(U8 *key, U8 *iv_nonce, FILE *fin, FILE *fout);
void aes_cbc_decrypt(U8 *key, FILE *fin, FILE *fout);

#endif

