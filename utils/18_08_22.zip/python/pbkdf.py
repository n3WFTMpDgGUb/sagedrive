import hashlib
from hmac import HMAC

def xor_bytes(x, y):
    """Return xor of the two bytes arrays x and y, padding the shorter
    with 0-bytes to match the length of the longer."""

    # Make x the longer of the two
    if (len(x) < len(y)):
        (x, y) = (y, x)
    n = len(x)

    # Pad y to size of x
    y += bytearray([0]*(n - len(y)))

    return bytes([x[i] ^ y[i] for i in range(n)])

def _pbkdf(password, index, salt, count, sha):
    """Derive portion of master_key for this index."""
    
    u = salt + index.to_bytes(4, byteorder="big")
    t = b''
    for j in range(1, count+1):
        u = HMAC(password, u, sha).digest()
        t = xor_bytes(u, t)

    return t

def pbkdf(password, mk_len, salt, count, sha):
    """Password-based key derivation, from NIST SP 800-132.
    Password and salt are byte objects or bytearrays.
    Returned master key is byte object of length mk_len."""
    
    mk = bytearray([])
    index = 0
    
    while len(mk) < mk_len:
        index += 1
        mk += _pbkdf(password, index, salt, count, sha)
        
    return bytes(mk[:mk_len])

if __name__ == "__main__":

    def tohex(x):
        s = ""
        for xx in x:
            s += "%02x " % xx
        return s.strip()

    name = "From RFC6070, PBKDF2 HMAC-SHA1 Test Vectors"
    password = b"password"
    mk_len = 20
    salt = b"salt"
    count = 1
    sha = hashlib.sha1

    mk = pbkdf(password, mk_len, salt, count, sha)
    
    print("\n" + name)
    print("password:", password.decode())
    print("salt:", salt.decode())
    print("count:", count)
    print("mk:", tohex(mk))

    
    name = "From RFC6070, PBKDF2 HMAC-SHA1 Test Vectors"
    password = b"password"
    mk_len = 20
    salt = b"salt"
    count = 4096
    sha = hashlib.sha1

    mk = pbkdf(password, mk_len, salt, count, sha)
    
    print("\n" + name)
    print("password:", password.decode())
    print("salt:", salt.decode())
    print("count:", count)
    print("mk:", tohex(mk))
    

    name = "From RFC 7914, Test Vectors for PBDKF2 with HMAC-SHA-256"
    password = b"passwd"
    mk_len = 64
    salt = b"salt"
    count = 1
    sha = hashlib.sha256

    mk = pbkdf(password, mk_len, salt, count, sha)
    
    print("\n" + name)
    print("password:", password.decode())
    print("salt:", salt.decode())
    print("count:", count)
    print("mk:", tohex(mk))

    

    name = "From RFC 7914, Test Vectors for PBDKF2 with HMAC-SHA-256"
    password = b"Password"
    mk_len = 64
    salt = b"NaCl"
    count = 80000
    sha = hashlib.sha256

    mk = pbkdf(password, mk_len, salt, count, sha)
    
    print("\n" + name)
    print("password:", password.decode())
    print("salt:", salt.decode())
    print("count:", count)
    print("mk:", tohex(mk))
 
