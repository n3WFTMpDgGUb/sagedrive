#
# Generate 56-byte AES-DES key-encryption-key (KEK) to protect
# keys that protect backup files.
#
# KEK derived using NIST SP 800-132 password-based key derivation
# using SHA256 as the hash function.
# This utility accommodates an arbitrarily long text passphrase
# as the password.
#

from pbkdf import pbkdf
import hashlib

# Parameters
salt = bytearray.fromhex(" \
    d4 ca d0 e0 a5 e7 98 3b 12 3d cb 5e 39 25 66 3b \
    73 fe ce 42 6b eb 2b 40 b9 31 c6 5a 36 38 4b 33 \
    ")
count = 10000
kek_len = 56


# Do a quick self test.  Just to check that system is correctly configured.
_count = 100
_passphrase = "password"
x = pbkdf(_passphrase.encode(), kek_len, salt, _count, hashlib.sha256)
assert x == bytearray.fromhex(" \
    9c 09 46 4c 80 1d c7 11 41 12 c5 59 98 ac 92 51 \
    05 05 57 2c 37 4f 43 89 81 dd f0 71 d1 4f f0 32 \
    49 7f 7d a5 3e 01 d4 08 20 ab 18 04 3b 47 e8 cd \
    c3 a1 ef 4e c7 ac cc 39 \
    ")

# Get passphrase
print("Enter/paste passphrase.  " +
      "Enter '.' (period) on its own line to terminate.")
words = []
while True:
    x = input().strip()
    if x == ".":
        break
    words.extend(x.split())
passphrase = " ".join(words)

# Calculate the KEK
kek = pbkdf(passphrase.encode(), kek_len, salt, count, hashlib.sha256)

# Tell the world
#
# Handy routine for displaying byte array as formatted hex string.
def tohex(x):
    s = ""
    n = 0
    for xx in x:
        s += "%02x " % xx
        n += 1
        if n == 16:
            s = s.strip() + "\n"
            n = 0
    return s
#
print("")
print("KEK size (bytes): ", kek_len)
print("Iteration count: ", count)
print("Hash function: SHA256")
#
print("Salt:\n" + tohex(salt))
print("Passphrase:\n" + passphrase + "\n")
print("KEK:\n" + tohex(kek) + "\n")
